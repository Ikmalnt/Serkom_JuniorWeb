<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wisata Brebres</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>
    <!-- navbar -->
   <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <header class="mt-5">
        <div class="container">
            <div id="carouselExampleIndicators" class="carousel slide">
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="<?php echo e(asset('assets/img/Masjid-Agung-Brebes (1).jpg')); ?>" class="d-block w-100 shadow-sm"
                            alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('assets/img/Tempat-Wisata-Brebes-Pabrik-Gula-Jatibarang.jpg')); ?>" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                        <img src="<?php echo e(asset('assets/img/Screenshot_20230123_152606.png')); ?>" class="d-block w-100" alt="...">
                    </div>
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                    data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                    data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
    </header>

    <main>
        <section class="wisata">
            <div class="container">
                <div class="judul">
                    <h2 class="mb-0">Wisata Kabupaten Brebes</h2>
                    <p>Jelajahi Wisata Alam Menarik</p>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="card p-3 shadow">
                            <img src="<?php echo e(asset('assets/img/maxresdefault.jpg')); ?>" alt="">
                            <div class="text-center mt-3">
                                <h3 class="fw-bold">Wisata Waduk Malahayu</h3>
                                <p class="text-muted">Waduk Malahayu berlokasi di Brebes, menyimpan keindahan yang
                                    jarang orang tahu dan rekomended untuk liburan dengan harga tiket masuk murah.</p>
                            </div>

                            <a href="/malahayu" class="btn btn-primary w-100 btn-detail">Detail Wisata</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card p-3 shadow">
                            <img src="<?php echo e(asset('assets/img/1205451276.jpg')); ?>" alt="">
                            <div class="text-center mt-3">
                                <h3 class="fw-bold">Hutan Mangrove</h3>
                                <p class="text-muted">Wahana berperahu dan jalan setapak kayu di tengah hutan bakau
                                    yang lebat, gubuk makan, dan toko suvenir.</p>
                            </div>

                            <a href="hutanmangrove" class="btn btn-primary w-100 btn-detail">Detail Wisata</a>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card p-3 shadow">
                            <img src="<?php echo e(asset('assets/img/Brebes-agrowisata-kaligua-foto-by-@explore_kaligua.png')); ?>"
                                alt="">
                            <div class="text-center mt-3">
                                <h3 class="fw-bold">Kebun Teh Kaligua</h3>
                                <p class="text-muted">Agrowisata Kaligua berlokasi di Brebes, menyajikan spot wahana
                                    menarik yang rekomended untuk berakhir pekan dengan harga tiket masuk murah.</p>
                            </div>

                            <a href="kebunteh" class="btn btn-primary w-100 btn-detail">Detail Wisata</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="text-center text-lg-start text-muted shadow-sm">
        <!-- Copyright -->
        <div class="text-center text-light p-4">
            © 2023 Copyright Made With ♥
            <a class="text-reset" href="/">Wisata Brebes</a>
        </div>
        <!-- Copyright -->
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\serkom\resources\views/welcome.blade.php ENDPATH**/ ?>