<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wisata Brebres</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdn.plyr.io/3.4.6/plyr.css">
</head>

<body>
    <!-- navbar -->
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <header class="mt-5">
        <div class="container">
           <div class="row">
            <div class="col-md-6">
                <div id="carouselExampleIndicators" class="carousel slide">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="<?php echo e(asset('assets/img/Brebes-agrowisata-kaligua-foto-by-@explore_kaligua.png')); ?>" class="d-block w-100 shadow-sm"
                                alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('assets/img/IMG_20211125_20580102.jpg')); ?>"
                                class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('assets/img/d494bbc0-ece7-496b-a2fe-4a2d72a475e3_169.png')); ?>" class="d-block w-100"
                                alt="...">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-3">
                    <div id="player" data-plyr-provider="youtube" data-plyr-embed-id="9u8-oTQYGOI"></div>
                </div>
            </div>
           </div>
        </div>
    </header>

    <main>
        <section class="wisata">
            <div class="container">

                <div class="judul">
                    <h2 class="mb-3">Kebun Teh Kaligua</h2>
                    <h3>Rp 25.000/Orang</h3>
                    <p>Kebun Kaligua sebenarnya merupakan perkebunan teh peninggalan zaman Belanda dan sekarang menjadi milik PT Perkebunan Nusantara IX.
                        Karena potensi alamnya yang indah, kebun ini sekaligus difungsikan sebagai tempat wisata agro.
                        Pengunjung bisa memilih tempat wisata di antaranya Goa Jepang, Tuk Bening, air terjun, wisata permainan, dan petualangan. Di samping banyak pilihannya,
                        letaknya juga berdekatan antara satu dengan yang lainnya sehingga mudah dijangkau.
                        Tak jauh dari tempat memarkir kendaraan, Anda sudah bisa menikmati pemandangan kebun teh. Ada fasilitas gazebo yang disediakan untuk tempat duduk-duduk.
                        Ada pula sungai kecil yang mengalir ke kolam untuk bermain perahu bebek. Bagi yang punya nyali tinggi,
                        bisa mencoba untuk bermain flying fox di atas hijaunya kebun teh. Jaraknya memang tidak terlalu jauh, tetapi cukup membuat jantung berdegup kencang.</p>
                </div>

            </div>
        </section>
    </main>

    <footer class="text-center text-lg-start text-muted shadow-sm">
        <!-- Copyright -->
        <div class="text-center text-light p-4">
            © 2023 Copyright Made With ♥
            <a class="text-reset" href="/">Wisata Brebes</a>
        </div>
        <!-- Copyright -->
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.plyr.io/3.4.6/plyr.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // This is the bare minimum JavaScript. You can opt to pass no arguments to setup.
            const player = new Plyr('#player');

            // Expose
            window.player = player;

            // Bind event listener
            function on(selector, type, callback) {
                document.querySelector(selector).addEventListener(type, callback, false);
            }

            // Play
            on('.js-play', 'click', () => {
                player.play();
            });

            // Pause
            on('.js-pause', 'click', () => {
                player.pause();
            });

            // Stop
            on('.js-stop', 'click', () => {
                player.stop();
            });

            // Rewind
            on('.js-rewind', 'click', () => {
                player.rewind();
            });

            // Forward
            on('.js-forward', 'click', () => {
                player.forward();
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\serkom\resources\views/kebunteh.blade.php ENDPATH**/ ?>