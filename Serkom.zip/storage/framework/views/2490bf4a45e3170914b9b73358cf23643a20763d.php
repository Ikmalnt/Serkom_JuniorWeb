<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wisata Brebres</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdn.plyr.io/3.4.6/plyr.css">
</head>

<body>
    <!-- navbar -->
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <header class="mt-5">
        <div class="container">
           <div class="row">
            <div class="col-md-6">
                <div id="carouselExampleIndicators" class="carousel slide">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="<?php echo e(asset('assets/img/maxresdefault.jpg')); ?>" class="d-block w-100 shadow-sm"
                                alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('assets/img/Screenshot_20230123_183318.png')); ?>"
                                class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('assets/img/Screenshot_20230123_152606.png')); ?>" class="d-block w-100"
                                alt="...">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators"
                        data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators"
                        data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card p-3">
                    <div id="player" data-plyr-provider="youtube" data-plyr-embed-id="LeN06MRhtNo"></div>
                </div>
            </div>
           </div>
        </div>
    </header>

    <main>
        <section class="wisata">
            <div class="container">

                <div class="judul">
                    <h2 class="mb-3">Wisata Waduk Malahayu</h2>
                    <h3>Rp 10.000/Orang</h3>
                    <p>Menikmati keindahan alam yang di sajikan oleh destinasi Waduk Malahayu Brebes, anda tidak akan
                        merasa keberatan. Karena untuk menghabiskan hari libur di Waduk Malahayu, anda tidak akan
                        kehilangan banyak biaya.

                        Harga tiket masuk destinasi wisata Waduk Malahayu yang murah membuat tempat ini selalu ramai
                        akan pengunjung. Cukup dengan tiket masuk seharga Rp.10.000/orang, anda bisa menikmati keindahan
                        dan spot wisata Waduk Malahayu sepuas hati.

                        Dengan retribusi tambahan parkir kendaraan wisata Rp.2.000/motor dan mobil Rp.5.000 di Waduk
                        Malahayu. Anda bisa mendapatkan pengalaman liburan yang tak terlupakan dengan keindahan Waduk
                        Brebes satu ini.

                        Untuk biaya tiket masuk dan parkir di Waduk Malahayu bisa berubah setiap waktu. Dengan
                        operasional wisata Waduk Malahayu buka setiap hari selama 24 jam, anda bisa puas explore
                        destinasi Brebes satu ini.</p>
                </div>

            </div>
        </section>
    </main>

    <footer class="text-center text-lg-start text-muted shadow-sm">
        <!-- Copyright -->
        <div class="text-center text-light p-4">
            © 2023 Copyright Made With ♥
            <a class="text-reset" href="/">Wisata Brebes</a>
        </div>
        <!-- Copyright -->
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
    <script src="https://cdn.plyr.io/3.4.6/plyr.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // This is the bare minimum JavaScript. You can opt to pass no arguments to setup.
            const player = new Plyr('#player');

            // Expose
            window.player = player;

            // Bind event listener
            function on(selector, type, callback) {
                document.querySelector(selector).addEventListener(type, callback, false);
            }

            // Play
            on('.js-play', 'click', () => {
                player.play();
            });

            // Pause
            on('.js-pause', 'click', () => {
                player.pause();
            });

            // Stop
            on('.js-stop', 'click', () => {
                player.stop();
            });

            // Rewind
            on('.js-rewind', 'click', () => {
                player.rewind();
            });

            // Forward
            on('.js-forward', 'click', () => {
                player.forward();
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\serkom\resources\views/malahayu.blade.php ENDPATH**/ ?>