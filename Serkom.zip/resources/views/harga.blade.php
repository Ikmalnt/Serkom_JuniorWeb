<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Wisata Brebres</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
</head>

<body>
    <!-- navbar -->
    @include('navbar')

    <main>
        <section class="wisata">
            <div class="container">
                <div class="judul">
                    <h2 class="mb-2">Wisata Kabupaten Brebes</h2>
                    <p>Faktanya, sebagai kabupaten terluas kedua di Jawa Tengah setelah Cilacap, Brebes memiliki potensi wisata dan alam yang tiada duanya. Kota yang terkenal sebagai penghasil telur asin dan bawang merah di Indonesia ini juga memiliki bentang alam dan lanskap yang begitu memesona. Kreativitas warganya untuk memberikan warna tersendiri pada setiap destinasi wisata yang ada juga menjadikan Brebes menjadi salah satu tujuan wisata alternatif di wilayah Pantai Utara Jawa.

                    </p>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="card p-3 shadow">
                            <img src="{{ asset('assets/img/maxresdefault.jpg') }}" alt="">
                            <div class="text-center mt-3">
                                <h3 class="fw-bold">Wisata Waduk Malahayu</h3>
                                <p class="text-muted">Waduk Malahayu berlokasi di Brebes, menyimpan keindahan yang
                                    jarang orang tahu dan rekomended untuk liburan dengan harga tiket masuk murah.</p>
                            </div>
                            <h4 class="text-center">Rp 10.000</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card p-3 shadow">
                            <img src="{{ asset('assets/img/1205451276.jpg') }}" alt="">
                            <div class="text-center mt-3">
                                <h3 class="fw-bold">Hutan Mangrove</h3>
                                <p class="text-muted">Wahana berperahu dan jalan setapak kayu di tengah hutan bakau
                                    yang lebat, gubuk makan, dan toko suvenir.</p>
                            </div>
                            <h4 class="text-center">Rp 14.000</h4>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="card p-3 shadow">
                            <img src="{{ asset('assets/img/Brebes-agrowisata-kaligua-foto-by-@explore_kaligua.png') }}"
                                alt="">
                            <div class="text-center mt-3">
                                <h3 class="fw-bold">Kebun Teh Kaligua</h3>
                                <p class="text-muted">Agrowisata Kaligua berlokasi di Brebes, menyajikan spot wahana
                                    menarik yang rekomended untuk berakhir pekan dengan harga tiket masuk murah.</p>
                            </div>
                            <h4 class="text-center">Rp 25.000</h4>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <footer class="text-center text-lg-start text-muted shadow-sm">
        <!-- Copyright -->
        <div class="text-center text-light p-4">
            © 2022 Copyright Made With ♥
            <a class="text-reset" href="/">Wisata Brebes</a>
        </div>
        <!-- Copyright -->
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous">
    </script>
</body>

</html>
